document.addEventListener("DOMContentLoaded", function () {
    const submitButton = document.getElementById("Submit");
    const nextStep2 = document.getElementById("next-step-2");
    const downloadQR = document.getElementById("download-qr");
    const downloadLabel = document.getElementById("download-label");

    // Show return label section after clicking Submit
    submitButton.addEventListener("click", function () {
        document.getElementById("return-labels").classList.remove("hidden");
    });

    // Show return status section after clicking next and update progress colors
    nextStep2.addEventListener("click", function () {
        document.getElementById("return-status").classList.remove("hidden");

        // Update progress status
        const progressItems = document.querySelectorAll("#return-status ul li");

        progressItems[0].style.color = "green"; // "Return Request Successful" - Completed
        progressItems[1].style.color = "grey";  // "To be Shipped" - Pending
        progressItems[2].style.color = "grey";  // "Returned Package Received" - Pending
        progressItems[3].style.color = "grey";  // "Refunding" - Pending
        progressItems[4].style.color = "grey";  // "Refunded Successfully" - Pending
    });

    // Download QR Code
    downloadQR.addEventListener("click", function () {
        const qrCode = document.getElementById("qr-code").src;
        downloadImage(qrCode, "qr-code.png");
    });

    // Download Return Label
    downloadLabel.addEventListener("click", function () {
        const returnLabel = document.getElementById("return-label").src;
        downloadImage(returnLabel, "return-label.png");
    });

    function downloadImage(imageUrl, fileName) {
        const link = document.createElement("a");
        link.href = imageUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
});
