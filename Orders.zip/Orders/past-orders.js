document.addEventListener("DOMContentLoaded", function() {
    const ordersContainer = document.getElementById("orders-container");

    // replace with actual images and past orders
    const pastOrders = [
        {
            orderId: "ORD12345",
            productName: "APPLE 11 iPad Air (2024) - 128 GB",
            image: "c:/Users/mjaer/Documents/Past orders/images/Screenshot 2024-12-01 141723.png",
            price: "£599.00",
            quantity: 1
        },

        {
            orderId: "ORD12346",
            productName: "LENOVO Tab P12 12.7 Tablet - 128 GB",
            image: "c:/Users/mjaer/Documents/Past orders/images/Lenovo.svg",
            price: "£299.00",
            quantity: 1
        },
        {
            orderId: "ORD12347",
            productName: "Apple AirPods 4  - White",
            image: "c:/Users/mjaer/Documents/Past orders/images/Screenshot 2025-02-20 152826.png",
            price: "£199.00",
            quantity: 1
        }
    ];

    pastOrders.forEach(order => {
        const orderCard = document.createElement("div");
        orderCard.classList.add("order-card");

        orderCard.innerHTML = `
    <img src="${order.image}" alt="${order.productName}" class="order-image">
    <div class="order-info">
        <h3>Order #${order.orderId}</h3>
        <p><strong>Product:</strong> ${order.productName}</p>
        <p><strong>Quantity:</strong> ${order.quantity}</p>
        <p><strong>Total Cost:</strong> ${order.price}</p>
    </div>
    <button class="return-btn" onclick="requestReturn('${order.orderId}')">Request Return</button>
`;


        ordersContainer.appendChild(orderCard);
    });
});

function requestReturn(orderId) {
    alert(`Your return request for Order #${orderId} has been submitted.`);
}
